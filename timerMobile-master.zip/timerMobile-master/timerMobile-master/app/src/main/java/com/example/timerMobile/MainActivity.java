package com.example.timerMobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements ControlFragment.OnFragmentInteractionListener{

    Intent intent;
    ListFragment listFragment;
    ControlFragment controlFragment;
    public final static String LIST="list";
    boolean pause = false;
    boolean flip = false;
    int startC = 0;
    String message = "";
    MyAsyncTask myAsyncTask;
    int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //initialize DeptInformation class
        //create fragment references
        listFragment= (ListFragment) getSupportFragmentManager().findFragmentById(R.id.listFrag);
        controlFragment= (ControlFragment) getSupportFragmentManager().findFragmentById(R.id.controlFrag);
        //initialize AsyncTask class
        myAsyncTask= new MyAsyncTask();

    }



    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("mess", message);
        //Toast.makeText(this, outState.getString("mess"), Toast.LENGTH_SHORT).show();
        outState.putInt("count", count);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        count = savedInstanceState.getInt("count");
        if (count > 9){
            controlFragment.counter.setText("00:00:" + count);
        }
        else {
            controlFragment.counter.setText("00:00:0" + count);
        }
        message = savedInstanceState.getString("mess");
        if(listFragment!=null && listFragment.isInLayout()){
            listFragment.setText(message);
            flip = true;
        }
        else{
            intent = new Intent(this, ListActivity.class);
            intent.putExtra(LIST, message);
            flip = false;
        }
    }

    @Override
    protected void onDestroy() {
        //checking if asynctask is still runnning
        if(myAsyncTask!=null && myAsyncTask.getStatus()== AsyncTask.Status.RUNNING){
            //cancel the task before destroying activity
            myAsyncTask.cancel(true);
            myAsyncTask= null;
        }
        super.onDestroy();
    }

    @Override
    public void onButtonClicked(int infoID) {
        if (infoID == 2){
            if (startC == 0){
                startC++;
                pause = false;

            }
            else{
                startC = 0;
                pause = true;
            }
        }
        if(infoID!= 2){
            if(listFragment!=null && listFragment.isInLayout()){
            //informationfragment exists on screen, so we are in landscape mode
                if (count > 9){
                    message = message + "Lap Time = " + "00:00:" +Integer.toString(count) + " seconds\n";
                    listFragment.endText(message);
                }
                else{
                    message = message + "Lap Time = " + "00:00:0" +Integer.toString(count) + " seconds\n";
                    listFragment.endText(message);
                }
                count = 0;
                controlFragment.counter.setText("00:00:00");
                if (infoID == 1){
                    message = "";
                    listFragment.endText("");
                }

            }else{
                //for portrait mode
                if (infoID != 3) {
                    intent = new Intent(this, ListActivity.class);
                    if (infoID == 0){
                        if (count > 9){
                            message = message + "Lap Time = " + "00:00:" + Integer.toString(count) + " seconds\n";
                            intent.putExtra(LIST, message);
                        }
                        else {
                            message = message + "Lap Time = " + "00:00:0" + Integer.toString(count) + " seconds\n";
                            intent.putExtra(LIST, message);
                        }
                    }
                    else if (infoID == 1){
                        intent.putExtra(LIST, "");
                        message = "";
                    }
                    count = 0;
                    controlFragment.counter.setText("00:00:00");
                }
                else if (infoID == 3) {
                    startActivity(intent);
                }
            }
        }else {
            //executing asynctask on button click
            //first checking if it is already running or not

            if(myAsyncTask.getStatus()!= AsyncTask.Status.RUNNING){
                myAsyncTask = new MyAsyncTask();
                //passing in 20 as the limit and executing the task
                myAsyncTask.execute(20);
            }
        }
    }

    private class MyAsyncTask extends AsyncTask<Integer, Integer, Void> {

        @Override
        protected Void doInBackground(Integer... params) {
            while(count < 1000000){
                try{
                    //checking if the asynctask has been cancelled, end loop if so
                    if(isCancelled()) break;
                    if (pause == true){
                        //Do Nothing
                    }
                    else {
                        Thread.sleep(500);

                        count++;

                        //send count to onProgressUpdate to update UI
                        publishProgress(count);
                    }

                }catch(Exception e){
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            //setting count to 0 and setting textview to 0 after doInBackground finishes running
            count= 0;
            controlFragment.counter.setText("00:00:00");

        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            if (count > 9){
                controlFragment.counter.setText("00:00:" + values[0]+"");
            }
            else {
                controlFragment.counter.setText("00:00:0" + values[0] + "");
            }

        }
    }

}