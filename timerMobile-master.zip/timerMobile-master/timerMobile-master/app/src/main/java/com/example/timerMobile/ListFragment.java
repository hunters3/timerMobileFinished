package com.example.timerMobile;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class ListFragment extends Fragment {

    TextView lap;

    public ListFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_list, container, false);
        lap = view.findViewById(R.id.lapData);
        return view;
    }

    public void setText(String text) {
        lap.append(text + '\n');
    }

    public void endText(String text) {
        lap.setText(text + '\n');
    }

}