package com.example.timerMobile;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


public class ControlFragment extends Fragment implements View.OnClickListener{

    Button lap;
    Button reset;
    Button async;
    Button nextPg;
    TextView counter;
    boolean start = false;
    //declare interaction listener
    private OnFragmentInteractionListener mListener;

    public ControlFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view= inflater.inflate(R.layout.fragment_control, container, false);

        //initialize buttons and textview
        lap = (Button) view.findViewById(R.id.lapButton);
        reset= (Button) view.findViewById(R.id.resetButton);
        async = (Button) view.findViewById(R.id.asyncButton);
        nextPg = (Button) view.findViewById(R.id.nextButton);
        counter= (TextView) view.findViewById(R.id.count);

        //add listeners
        lap.setOnClickListener(this);
        reset.setOnClickListener(this);
        async.setOnClickListener(this);
        nextPg.setOnClickListener(this);


        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        if(context instanceof OnFragmentInteractionListener){
            this.mListener= (OnFragmentInteractionListener) context;
        }else{
            throw new RuntimeException(context.toString()+" must implement OnFragmentInteractionListener");
        }

    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    public void onClick(View view){
        if(view.getId() == lap.getId()){

            mListener.onButtonClicked(0);

        }else if (view.getId() == reset.getId()){

            mListener.onButtonClicked(1);

        } else if(view.getId() == async.getId() ){
            if (start == true){
                start = false;
                async.setText("Start");
            }
            else{
                async.setText("Stop");
                start = true;
            }
            mListener.onButtonClicked(2);
        }
        else if (view.getId() == nextPg.getId()){
            mListener.onButtonClicked(3);
        }
    }

    public interface OnFragmentInteractionListener{
        void onButtonClicked(int infoID);
    }
}